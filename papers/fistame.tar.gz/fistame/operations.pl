/*

Finite-State Methods in Natural-Language Processing: Algorithms

Original paper by Ronald M. Kaplan and Martin Kay..............

Fistame Prolog implementation by Ralph Debusmann...............

operations.pl ... Revision date 04/02/99.......................

*/

:- multifile start/2,trans/4,final/2.

:- dynamic start/2,trans/4,final/2.

%% Unary operations

% Print an automaton

start(cat(A),S):-
  start(A,S),
  format("~nautomaton ~w~nstart state ~w~n",[A,S]).

trans(cat(A),S,X,D):-
  trans(A,S,X,D),
  format("from ~w over ~w to ~w~n",[S,X,D]).

final(cat(A),S):-
  final(A,S),
  format("final state ~w~n",[S]).

process_state(cat(A),S):-
  \+start(A,S),
  format("state ~w~n",[S]).

% Complement an automaton (nested operation)

start(complement(A),S):-
  start(inv(det(complete(A))),S).

trans(complement(A),S,X,D):-
  trans(inv(det(complete(A))),S,X,D).

final(complement(A),S):-
  final(inv(det(complete(A))),S).

% Complete an automaton

start(complete(A),S):-
  start(A,S),
  scan(sig(A)).

trans(complete(A),S1,X,S2):-
  trans(A,S1,X,S2).
trans(complete(A),S1,X,dead):-
  symbol(A,X),
  \+trans(A,S1,X,_).

final(complete(A),S):-
  final(A,S).

% Copy automata (unary)

start(cp(A),S):-
  start(A,S),
  retractall(start(copy,_)),
  retractall(trans(copy,_,_,_)),
  retractall(final(copy,_)),
  assert(start(copy,S)).

trans(cp(A),S,X,D):-
  trans(A,S,X,D),
  assert(trans(copy,S,X,D)).

final(cp(A),S):-
  final(A,S),
  assert(final(copy,S)).

% Copy automata and remove epsilon-transitions (unary)

start(cp_rep(A),S):-
  start(cp(A),S).

trans(cp_rep(A),S,X,D):-
  ec_trans(A,S,X,D),
  assert(trans(copy,S,X,D)).

final(cp_rep(A),S):-
  epsilon_closure(A,[S],[],EC),
  member(P,EC),
  final(A,P),
  assert(final(copy,S)).

% Determinize automata

start(det(A),Ss):-
  setof(X,start(A,X),Ss).

trans(det(A),Ss,X,Ds):-
  setof(D,S^(member(S,Ss),trans(A,S,X,D)),Ds).

final(det(A),Ss):-
  member(S,Ss),
  final(A,S).

% Determinize automata (plus remove epsilon-transitions)

start(det_rep(A),Ss):-
  start(det(A),Ss).

trans(det_rep(A),Ss,X,Ds):-
  setof(D,(S^member(S,Ss),ec_trans(A,S,X,D)),Ds).

final(det_rep(A),Ss):-
  member(S,Ss),
  epsilon_closure(A,[S],[],EC),
  member(P,EC),
  final(A,P).

% Invert an automaton

start(inv(A),S):-
  start(A,S).
  
trans(inv(A),S,X,D):-
  trans(A,S,X,D).
  
final(inv(A),S):-
  \+final(A,S).

% Minimize an automaton

start(mini(A),C):-
  ensure_minimized(A),
  inactive(A,Cs),
  member(C,Cs),
  member(S,C),
  start(A,S).

trans(mini(A),[S|C1s],X,C2):-
  ensure_minimized(A),
  inactive(A,Cs),
  member([S|C1s],Cs),
  member(C2,Cs),
  member(D,C2),
  trans(A,S,X,D).

final(mini(A),C):-
  ensure_minimized(A),
  inactive(A,Cs),
  member(C,Cs),
  member(S,C),
  final(A,S).

% Reverse an automaton

start(rev(_),S):-
  (  var(S)
  -> gen(s,S)
  ).

trans(rev(A),S,ep,D):-
  \+start(A,S),
  final(A,D),
  ispre(s,S).
trans(rev(A),S,X,D):-
  trans(A,D,X,S).

final(rev(A),S):-
  start(A,S).

% Assert the signature of an automaton

start(sig(A),S):-
  start(A,S),
  retractall(symbol(A,_)).      % reset symbol assertion for automaton A at first

trans(sig(A),S1,X,S2):-
  trans(A,S1,X,S2),
  (  symbol(A,X)                % symbol already asserted?
  -> true                       % yes -> go to the next transition
  ;  assert(symbol(A,X))        % no -> assert it
  ).

% Generate an automaton out of a string

start(string(X1),X2):-
  atomtolist(X1,X2).

trans(string(_),[X],X,[]).
trans(string(_),[X1|[X2|Xs]],X1,[X2|Xs]):-
  trans(string(_),[X2|Xs],X2,Xs).

final(string(_),[]).

% Copy automata (binary)

start(cp(A1,A2),S):-
  start(A1,S),
  retractall(start(A2,_)),
  retractall(trans(A2,_,_,_)),
  retractall(final(A2,_)),
  assert(start(A2,S)).

trans(cp(A1,A2),S,X,D):-
  trans(A1,S,X,D),
  assert(trans(A2,S,X,D)).

final(cp(A1,A2),S):-
  final(A1,S),
  assert(final(A2,S)).

% Copy automata and remove epsilon-transitions (binary)

start(cp_rep(A1,A2),S):-
  start(cp(A1,A2),S).

trans(cp_rep(A1,A2),S,X,D):-
  ec_trans(A1,S,X,D),
  assert(trans(A2,S,X,D)).

final(cp_rep(A1,A2),S):-
  epsilon_closure(A1,[S],[],EC),
  member(P,EC),
  final(A1,P),
  assert(final(A2,S)).

% Intersect automata

start((A1,A2),S1/S2):-
  start(A1,S1),
  start(A2,S2).

trans((A1,A2),S1/S2,X,D1/D2):-
  trans(A1,S1,X,D1),
  trans(A2,S2,X,D2).

final((A1,A2),S1/S2):-
  final(A1,S1),
  final(A2,S2).

% Produce the union of automata

start((_;_),start).

trans((A1;_),start,ep,1/S1):-
  start(A1,S1).
trans((_;A2),start,ep,2/S2):-
  start(A2,S2).
trans((A1;_),1/S1,X,1/D1):-
  trans(A1,S1,X,D1).
trans((_;A2),2/S2,X,2/D2):-
  trans(A2,S2,X,D2).

final((A1;_),1/S1):-
  final(A1,S1).
final((_;A2),2/S2):-
  final(A2,S2).
