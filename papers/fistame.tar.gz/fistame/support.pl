/*

Finite-State Methods in Natural-Language Processing: Algorithms

Original paper by Ronald M. Kaplan and Martin Kay..............

Fistame Prolog implementation by Ralph Debusmann...............

support.pl ... Revision date 10/27/98..........................

*/

% Epsilon-closure of an automaton

epsilon_closure(A,[S|Ss],Done,EC):-
  member(S,Done),!,
  epsilon_closure(A,Ss,Done,EC).
epsilon_closure(A,[S|Ss1],Done,EC):-
  (  setof(D,trans(A,S,ep,D),Ds)
  -> append(Ds,Ss1,Ss2),
     epsilon_closure(A,Ss2,[S|Done],EC)
  ;  epsilon_closure(A,Ss1,[S|Done],EC)
  ).
epsilon_closure(_,[],Done,Done).

ec_trans(A,S,X,D):-
  epsilon_closure(A,[S],[],EC),
  member(P,EC),
  trans(A,P,X,D),
  \+X=ep.

% Ensure that an automaton is minimized

ensure_minimized(A):-
  (  active(A,[]),
     inactive(A,_)
  -> true
  ;  minimize(A)
  ).

% Is an automaton empty?

empty(A):-
  remove(empty),
  scan(cp(A,empty)),
  \+final(empty,_).

% Does an automaton accept a certain string?

accept(A,S):-
  remove(accept1),
  remove(accept2),
  scan(cp_rep(A,accept1)),
  scan(cp((accept1,string(S)),accept2)),
  \+empty(accept2).

% Remove an automaton

remove(A):-
  retractall(start(A,_)),
  retractall(trans(A,_,_,_)),
  retractall(final(A,_)).

% Remove all automata and reload examples

reset:-
  retractall(start(_,_)),
  retractall(trans(_,_,_,_)),
  retractall(final(_,_)),
  resetgen,
  consult(operations),
  consult(examples).

% Generate unique symbols

gen(P,S1):-
  (  retract(counter(P,C))
  -> C1 is C+1
  ;  C1=0
  ),
  assert(counter(P,C1)),
  name(P,P1),
  name(C1,C2),
  append(P1,C2,S),
  name(S1,S).

resetgen:-
  retractall(counter(_,_)).

resetgen(P):-
  retract(counter(P,_)).

ispre(P,S):-
  (  atomic(P),
     atomic(S)
  -> name(P,P1),
     name(S,S1),
     append(P1,_,S1)
  ).

% Convert atom to atom list (e.g. abcc -> [a,b,c,c])

atomtolist(X,Xs):-
  name(X,X1),
  atomtolist1(X1,Xs).

atomtolist1([],[]).
atomtolist1([X1|X1s],[X2|X2s]):-
  name(X2,[X1]),
  atomtolist1(X1s,X2s).
