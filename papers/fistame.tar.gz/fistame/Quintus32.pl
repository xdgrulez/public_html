/*

Finite-State Methods in Natural-Language Processing: Algorithms

Original paper by Ronald M. Kaplan and Martin Kay..............

Fistame Prolog implementation by Ralph Debusmann...............

quintus.pl ... Revision date 10/27/98..........................

*/

% Quintus Prolog 3.2 startup

% Declare these predicates dynamic

:- dynamic state/2,symbol/2,counter/2.

% member/2 predicate
% * only needed for Quintus 3.2 *

member(X,[X|_]).
member(X,[_|Xs]):-   
  member(X,Xs).

% Ensure that all needed files are loaded

:- ensure_loaded([scan,support,minimize,operations,examples]).

% Reset Gen(Sym)-Counter

:- resetgen.
