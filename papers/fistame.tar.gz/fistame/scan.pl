/*

Finite-State Methods in Natural-Language Processing: Algorithms

Original paper by Ronald M. Kaplan and Martin Kay..............

Fistame Prolog implementation by Ralph Debusmann...............

scan.pl ... Revision date 04/22/99.............................

*/

% The main predicate, backbone for most of the code

scan(A):-
  retractall(state(A,_)),       % retract state markers
  start(A,S),                   % find start state
  scan_state(A,S).              % start scanning from there

scan_state(A,S):-
  state(A,S),!.                 % state already scanned?
scan_state(A,S):-
  assert(state(A,S)),           % mark state as scanned
  do_process_state(A,S),        % process state
  (  setof(D,X^trans(A,S,X,D),Ds)
  -> scan_states(A,Ds)
  ;  true                       % scan states reachable from the current one
  ).

do_process_state(A,S):-
  final(A,S).                   % final states receive special treatment
do_process_state(A,S):-
  process_state(A,S).           % process state
do_process_state(_,_).          % no processing possible - just return true

scan_states(A,[S|Ss]):-
  scan_state(A,S),              % scan state from state list
  scan_states(A,Ss).            % go to next state from state list
scan_states(_,[]).              % state list already emptied?










