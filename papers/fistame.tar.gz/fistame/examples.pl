/*

Finite-State Methods in Natural-Language Processing: Algorithms

Original paper by Ronald M. Kaplan and Martin Kay..............

Fistame Prolog implementation by Ralph Debusmann...............

examples.pl ... Revision date 10/16/98.........................

*/

:- multifile start/2,trans/4,final/2.

:- dynamic start/2,trans/4,final/2.

% Example machines

% a1 (FSA 1 in the paper)

start(a1,1).
trans(a1,1,a,2).
trans(a1,1,a,4).
trans(a1,2,b,3).
trans(a1,3,c,3).
final(a1,3).

% a2 (FSA 2), adds one epsilon transition to a1

start(a2,1).
trans(a2,1,a,2).
trans(a2,1,a,4).
trans(a2,2,b,3).
trans(a2,3,c,3).
trans(a2,4,ep,2).
final(a2,3).

% a3, a4 and a5 might be minimized

start(a3,1).
trans(a3,1,a,2).
trans(a3,1,b,3).
trans(a3,2,a,4).
trans(a3,3,a,4).
final(a3,4).

start(a4,0).
trans(a4,0,a,1).
trans(a4,0,b,8).
trans(a4,1,p,2).
trans(a4,1,q,5).
trans(a4,2,x,3).
trans(a4,2,y,4).
trans(a4,5,x,6).
trans(a4,5,y,7).
trans(a4,8,p,9).
trans(a4,8,q,11).
trans(a4,9,x,10).
trans(a4,11,y,12).
final(a4,1).
final(a4,3).	
final(a4,4).
final(a4,6).
final(a4,7).
final(a4,8).
final(a4,10).
final(a4,12).

start(a5,1).
trans(a5,1,0,2).
trans(a5,2,0,3).
trans(a5,3,0,4).
trans(a5,4,0,5).
trans(a5,5,0,6).
trans(a5,6,0,6).
trans(a5,1,1,1).
trans(a5,2,1,2).
trans(a5,3,1,3).
trans(a5,4,1,4).
trans(a5,5,1,5).
trans(a5,6,1,6).
final(a5,6).

% a6

start(a6,1).
trans(a6,1,a,2).
trans(a6,1,b,2).
trans(a6,2,b,3).
trans(a6,2,a,3).
final(a6,3).
