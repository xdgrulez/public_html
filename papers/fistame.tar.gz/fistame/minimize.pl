/*

Finite-State Methods in Natural-Language Processing: Algorithms

Original paper by Ronald M. Kaplan and Martin Kay..............

Fistame Prolog implementation by Ralph Debusmann...............

minimize.pl ... Revision date 04/02/99.........................

*/

% Just minimize it

% Declare these predicates dynamic (Sicstus 3)

:- dynamic active/2,inactive/2,mark/3,pseudo/2.

minimize(M):-
  scan(sig(M)),               % assert states and symbols of M
  setof(S,state(sig(M),S),Ss),% set of all states
  setof(X,symbol(M,X),Xs),      % set of all symbols (= the signature)
  split(M,Ss,final,SC,BC),      % split states
  cleara(M),
  cleari(M),
  pusha(M,SC),                  % smaller split class on active
  pushi(M,BC),                  % bigger on inactive
  assert(pseudo(M,BC)),         % bigger is pseudo-active
  minimize1(M,Xs),              % start it up
  geti(M,IC),
  format('~nInactive = ~w~n',[IC]).

minimize1(M,Xs):-
  (  popa(M,AC)                 % (while) get upmost active class
  -> format('Minimize using ~w~n',[AC]),
     pushi(M,AC),               % put it on inactive list
     minimize2(M,AC,Xs),        % start it up on a deeper level
     minimize1(M,Xs)            % (do)
  ;  true                       % end of (while do) loop
  ).

minimize2(_,_,[]).
minimize2(M,AC,[X|Xs]):-
  format('  Use symbol ~w~n',[X]),
  geta(M,ACs1),
  geti(M,ICs1),
  format('    Active   = ~w~n    Inactive = ~w~n',[ACs1,ICs1]),
  mark(M,AC,X,1),               % mark active class
  (  setof(S,marked(M,S),Ss)
  -> format('    Mark: ~w~n',[Ss]),
     geta(M,ACs),
     cleara(M),
     minimizea(M,ACs),
     geti(M,ICs),
     cleari(M),
     minimizei(M,ICs),          % till here - almost literate
     mark(M,AC,X,0),            % unmark active class
     minimize2(M,AC,Xs)         % do next symbol
  ;  format('    Mark: -~n',[]),
     minimize2(M,AC,Xs)
  ).

minimizea(_,[]).
minimizea(M,[C|Cs]):-
  split(M,C,marked,SC,BC),
  pusha(M,BC),
  pusha(M,SC),                  % put both split classes on active
  format('    Split active ~w into~n      ~w and~n      ~w~n',[C,SC,BC]),
  minimizea(M,Cs).              % do next class

minimizei(_,[]).
minimizei(M,[C|Cs]):-
  split(M,C,marked,SC,BC),
  pusha(M,SC),                  % smaller split class on active
  (  pseudo(M,C)                % if split class pseudo-active
  -> pusha(M,BC),               % then bigger on active
     retract(pseudo(M,C))       % retract pseudo-flag
  ;  pushi(M,BC)                % else bigger on inactive
  ),
  format('    Split inactive ~w into~n      ~w and~n      ~w~n',[C,SC,BC]),
  minimizei(M,Cs).              % do next class

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Split Classes

split(M,C,P,SC,BC):-
  split1(M,C,P,C1,C2),          % go splitting
  length(C1,L1),
  length(C2,L2),
  (  L1<L2
  -> C1=SC,
     C2=BC
  ;
     C1=BC,
     C2=SC
  ).                            % find out smaller and bigger classes (SC and BC)

split1(_,[],_,[],[]).
split1(M,[S|Ss],P,[S|C1],C2):-
  Test=..[P,M|[S]],
  Test,
  !,
  split1(M,Ss,P,C1,C2).
split1(M,[S|Ss],P,C1,[S|C2]):-
  split1(M,Ss,P,C1,C2).

% Mark Blundell

marked(M,S):-
  mark(M,S,1).

mark(_,[],_,_).
mark(M,[D|Ds],X,Mark):-
  (  setof(S,trans(M,S,X,D),Ss)
  -> mark1(M,Ss,Mark)
  ;  true
  ),
  mark(M,Ds,X,Mark).

mark1(_,[],_).
mark1(M,[S|Ss],Mark):-
  retractall(mark(M,S,_)),
  assert(mark(M,S,Mark)),
  mark1(M,Ss,Mark).

% Manipulate global lists

pusha(M,C):-
  push(M,C,active).
pushi(M,C):-
  push(M,C,inactive).
popa(M,C):-
  pop(M,C,active).
popi(M,C):-
  pop(M,C,inactive).
cleara(M):-
  clear(M,active).
cleari(M):-
  clear(M,inactive).
geta(M,Cs):-
  active(M,Cs).
geti(M,Cs):-
  inactive(M,Cs).

push(M,C,L):-
  (  C=[]
  -> true
  ;  P1=..[L,M,A],
     retract(P1),
     P2=..[L,M,[C|A]],
     assert(P2)
  ).
pop(M,C,L):-
  P1=..[L,M,[C|A]],
  retract(P1),
  P2=..[L,M,A],
  assert(P2).
clear(M,L):-
  P1=..[L,M,_],
  retractall(P1),
  P2=..[L,M,[]],
  assert(P2).
