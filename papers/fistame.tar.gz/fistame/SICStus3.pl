/*

Finite-State Methods in Natural-Language Processing: Algorithms

Original paper by Ronald M. Kaplan and Martin Kay..............

Fistame Prolog implementation by Ralph Debusmann...............

sicstus.pl ... Revision date 10/27/98..........................

*/

% Sicstus Prolog 3 startup

% Declare these predicates dynamic

:- dynamic state/2,symbol/2,counter/2.

% Consult list library predicates (incorporating append/3 and name/2)
% * only needed for Sicstus 3 *

:- use_module(library(lists)).

% Ensure that all needed files are loaded

:- ensure_loaded([scan,support,minimize,operations,examples]).

% Reset Gen(Sym)-Counter

:- resetgen.
